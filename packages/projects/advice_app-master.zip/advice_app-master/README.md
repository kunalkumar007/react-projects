# Introduction
This is a code repository for the corresponding video tutorial. 

In this video, we will create an interesting react project from scratch - A React Advice App. We're going to use React on the front end and we'll make get requests to Advice Slip JSON API.

By the end of this video, you will have a strong understanding of basic React workflow as well as how to make get requests in React Apps.

Setup:
- run ```npm i && npm start```
